#ifndef MAINUI_H
#define MAINUI_H
#include <iostream>
#include "PizzaUI.h"

using namespace std;

class MainUI
{
    public:
        MainUI();
        virtual ~MainUI();

        void startUI();
    private:
};

#endif // MAINUI_H
